class Source:
  def __init__(self,pagination):
    self.pagination = pagination
