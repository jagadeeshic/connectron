

class Source:
  def __init__(self,pagination):
    self.pagination = pagination


class Sink:
  def __init__(self,file_extension):
    self.file_extension = file_extension


class Authenticator:
  def __init__(self,client_id,client_secret):
    self.client_id = client_id
    self.client_secret = client_secret
