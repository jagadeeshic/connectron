from connectron.SourceMicrosoftDataverse import Source_MicrosoftDataverse

obj2 = Source_MicrosoftDataverse("cr86e_fs_auditscoreses",
                                            "aaaf4e73-0b5a-4e3e-95e3-b92fd4c692ab",
                                            "CjZ8Q~bv_hz~qvNMD1KcSwtWgzkvxBL2~Aod7cbc",
                                            "421794ae-eea0-4420-ab1a-a70e1841652c",
                                            "https://orgf3b7965a.crm.dynamics.com")