![CONNECTRON](/image.png)

Connectron is Unified AETL (Action,Extract,Transform,Load) connector for all Actions, Sources and Sink.

It is used to avoid regular boilerplate code.

Currently Supported:

        Sources: Microsoft Dataverse

        Sink: ADLS Gen2


Working:
        Works on 4 Objects Principle:

        1.Authenticator Object.
            * Create an Authenticator Object to Connect to Source or Sink.

        2.Source Object:
            * Connect to Source with Authentication object and Query Source.
            * You can Query Sources with different endpoints (API),Tables(Database),Files(Object Storage) with different parameters (Interval,Last x days,Filters,Select columns).
            * By Default it will provide converted object to Pandas Dataframe with Serilization(You can pass parameters as raw to get raw data fetched from Source)
            * You can use sample function available for Source to see Schema,Data without before downloading full Data.(You will get 100 records as Default).

        3.Sink Object:
            * Create Sink object to place objects at Sink.

        4. Action Object:
            * Any Trigger or Action.(eg. Sending a Email,Hitting an API endpoint,Refreshing PowerBI Dashboards,Triggering a Azure Function App,Sending Message on Telegram).
            * It can use the Same Authenticator Object for performing any Action.
Future Scope:

        Log Object: For Auditing connectron will store logs of all processes within connectron with:
                1. csv/json/parquet Files.
                2. Delta support in any cloud (Azure,AWS,GCP).