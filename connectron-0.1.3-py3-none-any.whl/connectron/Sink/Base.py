class Sink:
  def __init__(self,file_extension):
    self.file_extension = file_extension
    